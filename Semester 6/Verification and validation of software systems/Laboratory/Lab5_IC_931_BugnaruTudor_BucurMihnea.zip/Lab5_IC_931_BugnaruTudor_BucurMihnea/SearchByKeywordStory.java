package org.example.features.search;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import org.example.steps.serenity.EndUserSteps;

@RunWith(SerenityRunner.class)
public class SearchByKeywordStory {

    @Managed(uniqueSession = true)
    public WebDriver webdriver;

    @Steps
    public EndUserSteps anna;

    @Test
    public void searching_by_keyword_securitate_cibernetica_should_display_the_corresponding_article() {
        anna.is_the_home_page();
        anna.should_see_text("Securitate Cibernetică");
    }

    @Test
    public void searching_by_keyword_eit_digital_should_display_the_corresponding_article() {
        anna.is_the_home_page();
        anna.should_see_text("EIT Digital");
    }
}
