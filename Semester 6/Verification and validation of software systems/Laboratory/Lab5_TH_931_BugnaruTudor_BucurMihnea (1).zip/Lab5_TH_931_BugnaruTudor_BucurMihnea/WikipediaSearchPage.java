package org.example.pages;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.By;

@DefaultUrl("https://www.wikipedia.org/")
public class WikipediaSearchPage extends PageObject {

    public void searchFor(String keyword) {
        WebElementFacade searchBox = find(By.name("search"));
        searchBox.typeAndEnter(keyword);
    }

    public String getPageText() {
        return find(By.tagName("body")).getText();
    }
}
