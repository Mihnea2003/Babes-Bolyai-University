package org.example.features.search;

import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import net.thucydides.junit.annotations.UseTestDataFrom;
import org.example.steps.serenity.WikipediaUserSteps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/search_keywords.csv")
public class SearchByKeywordDDT {

    @Managed
    WebDriver driver;

    @Steps
    WikipediaUserSteps user;

    private String keyword;
    private String expectedResult;

    @Test
    public void search_results_should_contain_expected_text() {
        user.opens_home_page();
        user.searches_for(keyword);
        user.should_see_result_containing(expectedResult);
    }

    // Setters are needed for Serenity to inject values
    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public void setExpectedResult(String expectedResult) {
        this.expectedResult = expectedResult;
    }
}
