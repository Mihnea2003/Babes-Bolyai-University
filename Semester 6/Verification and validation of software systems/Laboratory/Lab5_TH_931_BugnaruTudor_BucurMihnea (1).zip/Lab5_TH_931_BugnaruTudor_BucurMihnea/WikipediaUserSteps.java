package org.example.steps.serenity;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import org.example.pages.WikipediaSearchPage;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;

public class WikipediaUserSteps extends ScenarioSteps {

    WikipediaSearchPage wikipediaPage;

    @Step
    public void opens_home_page() {
        wikipediaPage.open();
    }

    @Step
    public void searches_for(String keyword) {
        wikipediaPage.searchFor(keyword);
    }

    @Step
    public void should_see_result_containing(String expectedText) {
        assertThat(wikipediaPage.getPageText(), containsString(expectedText));
    }
}
